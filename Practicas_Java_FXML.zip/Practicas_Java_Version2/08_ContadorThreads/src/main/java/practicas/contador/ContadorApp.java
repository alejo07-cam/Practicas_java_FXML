package practicas.contador;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class ContadorApp extends Application {
    @Override public void start(Stage stage) throws Exception {
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/contador/contador.fxml"))));
        stage.setTitle("Contador y espera");
        stage.show();
    }
    public static void main(String[] args) { launch(args); }
}
