package practicas.contador;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
public class ContadorController {
    @FXML private Label lblCuenta;
    @FXML private ProgressBar barra;
    @FXML private Button btnEsperar;
    private int cuenta = 0;
    private boolean ocupado = false;
    @FXML private void contar() { cuenta++; lblCuenta.setText(String.valueOf(cuenta)); }
    @FXML private void esperar() {
        if (ocupado) return;
        ocupado = true; btnEsperar.setDisable(true); barra.setProgress(0);
        Thread tarea = new Thread(() -> {
            for (int i = 1; i <= 100; i++) {
                final int avance = i;
                Platform.runLater(() -> barra.setProgress(avance / 100.0));
                try { Thread.sleep(100); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
            }
            Platform.runLater(() -> { ocupado = false; btnEsperar.setDisable(false); });
        });
        tarea.setDaemon(true); tarea.start();
    }
}
