package practicas.dinero;
import javafx.fxml.FXML;
import javafx.scene.control.*;
public class DineroController {
    @FXML private TextField txtCantidad;
    @FXML private TextArea txtSalida;
    @FXML private void mostrar() {
        try {
            int restante = Integer.parseInt(txtCantidad.getText().trim());
            if (restante < 0) { txtSalida.setText("Escribe una cantidad positiva."); return; }
            int[] valores = {500, 200, 100, 50, 20, 10, 5, 2, 1};
            String[] tipos = {"Billetes de 500", "Billetes de 200", "Billetes de 100",
                    "Billetes de 50", "Billetes de 20", "Monedas de 10",
                    "Monedas de 5", "Monedas de 2", "Monedas de 1"};
            StringBuilder texto = new StringBuilder();
            for (int i = 0; i < valores.length; i++) {
                int cantidad = restante / valores[i];
                restante %= valores[i];
                texto.append(tipos[i]).append(": ").append(cantidad).append("\n");
            }
            txtSalida.setText(texto.toString());
        } catch (NumberFormatException e) { txtSalida.setText("Escribe un número entero."); }
    }
    @FXML private void limpiar() { txtCantidad.clear(); txtSalida.clear(); }
}
