public class Profesor extends Persona {
    private int clave;
    public Profesor(int clave) { super(); this.clave = clave; }
    @Override public String toString() {
        return "Un profesor de edad " + edad + ", con clave " + clave;
    }
}
