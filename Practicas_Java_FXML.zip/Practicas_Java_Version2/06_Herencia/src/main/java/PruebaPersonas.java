public class PruebaPersonas {
    public static void main(String[] args) {
        Alumno estudiante = new Alumno();
        Profesor docente = new Profesor(10008000);
        System.out.println(estudiante);
        System.out.println(docente);
    }
}
