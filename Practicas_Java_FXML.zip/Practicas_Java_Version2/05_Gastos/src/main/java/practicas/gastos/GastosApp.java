package practicas.gastos;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class GastosApp extends Application {
    @Override public void start(Stage stage) throws Exception {
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/gastos/gastos.fxml"))));
        stage.setTitle("Gastos semanales");
        stage.show();
    }
    public static void main(String[] args) { launch(args); }
}
