package practicas.gastos;
import javafx.fxml.FXML;
import javafx.scene.control.*;
public class GastosController {
    @FXML private TextField txtComida, txtSnacks, txtBus, txtCelular, txtVarios, txtTotal;
    @FXML private Label lblMayor;
    @FXML private void calcular() {
        try {
            int[] gastos = {Integer.parseInt(txtComida.getText()), Integer.parseInt(txtSnacks.getText()),
                Integer.parseInt(txtBus.getText()), Integer.parseInt(txtCelular.getText()), Integer.parseInt(txtVarios.getText())};
            String[] nombres = {"Alimentación", "Refrigerios", "Transporte", "Telefonía", "Otros"};
            int suma = 0, posicion = 0;
            for (int i = 0; i < gastos.length; i++) {
                if (gastos[i] < 0) { lblMayor.setText("No uses gastos negativos."); return; }
                suma += gastos[i];
                if (gastos[i] > gastos[posicion]) posicion = i;
            }
            txtTotal.setText(String.valueOf(suma));
            lblMayor.setText(nombres[posicion]);
        } catch (NumberFormatException e) { lblMayor.setText("Completa todos los campos con números."); }
    }
    @FXML private void limpiar() {
        txtComida.clear(); txtSnacks.clear(); txtBus.clear(); txtCelular.clear(); txtVarios.clear();
        txtTotal.clear(); lblMayor.setText("");
    }
}
