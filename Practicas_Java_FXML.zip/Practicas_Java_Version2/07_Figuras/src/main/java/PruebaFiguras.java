public class PruebaFiguras {
    public static void main(String[] args) {
        Figura2D figura = new TrianguloRect(3, 4);
        System.out.println(figura.imprimeFigura());
        figura = new Circulo(3);
        System.out.println(figura.imprimeFigura());
    }
}
