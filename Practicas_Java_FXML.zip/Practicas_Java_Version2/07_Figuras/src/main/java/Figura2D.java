public abstract class Figura2D implements FiguraPlana {
    public String imprimeFigura() { return "Se imprime una FiguraPlana..."; }
}
