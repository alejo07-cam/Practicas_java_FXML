public class Circulo extends Figura2D {
    private int radio;
    public Circulo(int radio) { this.radio = radio; }
    @Override public double calcularArea() { return Math.PI * radio * radio; }
    @Override public double calcularPerimetro() { return 2 * Math.PI * radio; }
    @Override public String imprimeFigura() {
        return super.imprimeFigura() + "\nCírculo: radio=" + radio
            + ", área=" + String.format(java.util.Locale.US, "%.2f", calcularArea())
            + ", perímetro=" + String.format(java.util.Locale.US, "%.2f", calcularPerimetro());
    }
}
