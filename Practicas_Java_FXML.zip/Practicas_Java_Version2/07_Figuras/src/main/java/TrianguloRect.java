public class TrianguloRect extends Figura2D {
    private int base, altura;
    public TrianguloRect(int base, int altura) { this.base = base; this.altura = altura; }
    @Override public double calcularArea() { return base * altura / 2.0; }
    @Override public double calcularPerimetro() { return base + altura + Math.sqrt(base*base + altura*altura); }
    @Override public String imprimeFigura() {
        return super.imprimeFigura() + "\nTriángulo rectángulo: base=" + base + ", altura=" + altura
            + ", área=" + String.format(java.util.Locale.US, "%.2f", calcularArea())
            + ", perímetro=" + String.format(java.util.Locale.US, "%.2f", calcularPerimetro());
    }
}
