package practicas.tabla;
import javafx.fxml.FXML;
import javafx.scene.control.*;
public class TablaController {
    @FXML private TextField txtNumero;
    @FXML private TextArea txtTabla;
    @FXML private void generar() {
        try {
            int n = Integer.parseInt(txtNumero.getText().trim());
            txtTabla.clear();
            for (int x = 1; x <= 10; x++) txtTabla.appendText(n + " x " + x + " = " + (n*x) + "\n");
        } catch (NumberFormatException e) { txtTabla.setText("Escribe un número entero."); }
    }
    @FXML private void limpiar() { txtNumero.clear(); txtTabla.clear(); }
}
