package practicas.tabla;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class TablaApp extends Application {
    @Override public void start(Stage stage) throws Exception {
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/tabla/tabla.fxml"))));
        stage.setTitle("Tabla de multiplicar");
        stage.show();
    }
    public static void main(String[] args) { launch(args); }
}
