package practicas.carrera;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.*;
public class CarreraController {
    @FXML private ProgressBar barraLiebre, barraTortuga;
    @FXML private Label lblEstado;
    @FXML private Button btnIniciar;
    private boolean enMarcha = false;
    @FXML private void iniciar() {
        if (enMarcha) return;
        enMarcha = true; btnIniciar.setDisable(true);
        barraLiebre.setProgress(0); barraTortuga.setProgress(0);
        lblEstado.setText("¡Comienza la carrera!");
        Thread carrera = new Thread(() -> {
            double liebre = 0, tortuga = 0;
            boolean pausa = false;
            try {
                while (liebre < 1 && tortuga < 1) {
                    if (!pausa && liebre >= 0.30) {
                        pausa = true;
                        Platform.runLater(() -> lblEstado.setText("La liebre se duerme un momento..."));
                        Thread.sleep(3000);
                    } else {
                        liebre += pausa ? 0.008 : 0.025;
                    }
                    tortuga += 0.012;
                    final double l = Math.min(1, liebre), t = Math.min(1, tortuga);
                    Platform.runLater(() -> { barraLiebre.setProgress(l); barraTortuga.setProgress(t); });
                    Thread.sleep(100);
                }
                String mensaje = tortuga >= 1 ? "¡Ganó la tortuga!" : "¡Ganó la liebre!";
                Platform.runLater(() -> lblEstado.setText(mensaje));
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            } finally {
                Platform.runLater(() -> { enMarcha = false; btnIniciar.setDisable(false); });
            }
        });
        carrera.setDaemon(true); carrera.start();
    }
}
