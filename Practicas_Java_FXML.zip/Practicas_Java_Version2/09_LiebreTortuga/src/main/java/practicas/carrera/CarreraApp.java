package practicas.carrera;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class CarreraApp extends Application {
    @Override public void start(Stage stage) throws Exception {
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/carrera/carrera.fxml"))));
        stage.setTitle("La liebre y la tortuga");
        stage.show();
    }
    public static void main(String[] args) { launch(args); }
}
