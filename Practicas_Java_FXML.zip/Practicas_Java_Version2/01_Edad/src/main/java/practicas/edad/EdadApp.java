package practicas.edad;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class EdadApp extends Application {
    @Override public void start(Stage stage) throws Exception {
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/edad/edad.fxml"))));
        stage.setTitle("Calcular edad");
        stage.show();
    }
    public static void main(String[] args) { launch(args); }
}
