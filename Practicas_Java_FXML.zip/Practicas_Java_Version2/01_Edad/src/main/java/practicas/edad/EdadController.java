package practicas.edad;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
public class EdadController {
    @FXML private TextField txtFecha;
    @FXML private Label lblRespuesta;
    @FXML private void calcular() {
        try {
            LocalDate fecha = LocalDate.parse(txtFecha.getText().trim(),
                    DateTimeFormatter.ofPattern("d/M/uuuu"));
            if (fecha.isAfter(LocalDate.now())) {
                lblRespuesta.setText("La fecha no puede ser futura.");
                return;
            }
            Period p = Period.between(fecha, LocalDate.now());
            lblRespuesta.setText(p.getYears() + " años y " + p.getMonths() + " meses");
        } catch (Exception e) {
            lblRespuesta.setText("Escribe la fecha como dd/mm/aaaa.");
        }
    }
    @FXML private void borrar() { txtFecha.clear(); lblRespuesta.setText(""); }
}
