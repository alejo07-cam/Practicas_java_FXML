package practicas.cifras;
import javafx.fxml.FXML;
import javafx.scene.control.*;
public class CifrasController {
    @FXML private TextField txtNumero, txtCantidad, txtImpares, txtPares, txtSuma, txtMayor, txtMenor;
    @FXML private TextArea txtDivisores;
    @FXML private void revisar() {
        try {
            long numero = Long.parseLong(txtNumero.getText().trim());
            String digitos = Long.toString(Math.abs(numero));
            int sumaPar = 0, sumaImpar = 0, mayor = 0, menor = 9;
            for (char c : digitos.toCharArray()) {
                int d = c - '0';
                if (d % 2 == 0) sumaPar += d; else sumaImpar += d;
                if (d > mayor) mayor = d;
                if (d < menor) menor = d;
            }
            txtCantidad.setText("" + digitos.length());
            txtImpares.setText("" + sumaImpar);
            txtPares.setText("" + sumaPar);
            txtSuma.setText("" + (sumaPar + sumaImpar));
            txtMayor.setText("" + mayor);
            txtMenor.setText("" + menor);
            txtDivisores.clear();
            long n = Math.abs(numero);
            if (n == 0) { txtDivisores.setText("El cero tiene infinitos divisores."); return; }
            for (long i = 1; i <= n; i++) if (n % i == 0) txtDivisores.appendText(i + "\n");
        } catch (NumberFormatException e) { txtDivisores.setText("Escribe un número entero válido."); }
    }
    @FXML private void limpiar() {
        txtNumero.clear(); txtCantidad.clear(); txtImpares.clear(); txtPares.clear();
        txtSuma.clear(); txtMayor.clear(); txtMenor.clear(); txtDivisores.clear();
    }
}
