package practicas.cifras;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
public class CifrasApp extends Application {
    @Override public void start(Stage stage) throws Exception {
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource("/cifras/cifras.fxml"))));
        stage.setTitle("Cifras y divisores");
        stage.show();
    }
    public static void main(String[] args) { launch(args); }
}
